struct ether_addr {
	unsigned char addr[6];
}__attribute__((packed));
typedef struct ether_addr ETHER_ADDR;

struct ip_addr {
	unsigned int addr;
}__attribute__((packed));
typedef struct ip_addr IP_ADDR;
//////

struct ether_header {
	ETHER_ADDR dst;
	ETHER_ADDR src;
	unsigned short type;
	/*
	 * ether types:
	 * 	0x0800 is IP
	 * 	0x86DD is IPv6
	 * 	0x8191 is NetBIOS
	 * 	0x0600 is Xerox XNS IDP
	 * 	0x0805 is X.25
	 * 	0x0806 is ARP
	 * 	0x0835 is RARP
	 * 	0x6003 is DEC DECnet Phase IV
	 * 	0x8137 is Novell Netware IPX
	 * 	0x8847 is MPLS
	 * 	0x8863 is PPPoE Discovery Stage
	 * 	0x8864 is PPPoE PPP Session Stage
	 */
}__attribute__((packed));
typedef struct ether_header ETHER_HEADER;

struct arp_header {
	unsigned short hardw_type; //hardware type
	unsigned short proto_type; //porotocol type
	unsigned char hard_addr_len; //hardware address len
	unsigned char proto_addr_len; //protocal address len
	unsigned short opcode; //operation code
	ETHER_ADDR src_mac_addr;
	unsigned int src_addr;
	ETHER_ADDR dst_mac_addr;
	unsigned int dst_addr;
	/* protocol_type same ether_types.
	 * if mac addr is "ff:ff:ff:ff:ff:ff", it is broadcast.
	 * operation code:
	 * 	1 is Arp Request
	 * 	2 is Arp Reply
	 * 	3 is Rarp Request
	 * 	4 is Rarp Reply
	 */
}__attribute__((packed));
typedef struct arp_header ARP_HEADER;

struct ip_header {
	unsigned char ip_header_len:4;
	unsigned char ip_version:4;
	unsigned char ip_tos;
	unsigned short ip_total_length;
	unsigned short ip_id;
	unsigned char ip_frag_offset:5;
	unsigned char ip_more_fragment:1;
	unsigned char ip_reserved_zero:1;
	unsigned char ip_frag_offset1;
	unsigned char ip_ttl;
	unsigned char ip_protocol;
	unsigned short ip_checksum;
	IP_ADDR ip_src_addr;
	IP_ADDR ip_dst_addr;
}__attribute__((packed));
typedef struct ip_header IP_HEADER;

struct tcp_header {
	unsigned short source_port;
	unsigned short dest_port;
	unsigned int sequence;
	unsigned int acknowledge;
	unsigned char ns:1;
	unsigned char reserved_part1:3;
	unsigned char data_offset:4;
	unsigned char fin:1;
	unsigned char syn:1;
	unsigned char rst:1;
	unsigned char psh:1;
	unsigned char ack:1;
	unsigned char urg:1;
	unsigned char ecn:1;
	unsigned char cwr:1;
	unsigned short window;
	unsigned short checksum;
	unsigned short urgent_pointer;
}__attribute__((packed));
typedef struct tcp_header TCP_HEADER; 

struct arp_packet {
	ETHER_HEADER ether_hdr;
	ARP_HEADER arp_hdr;
}__attribute__((packed));
typedef struct arp_packet ARP_PACKET;
