#include <stdio.h>
#include "pckt_header.h"

int main(void) {
	int i;
	ETHER_ADDR test_addr = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
	for(i = 0; i < 6; i++) {
		printf("%x", test_addr.addr[i]);
	} printf("\n");
	return 0;
}
