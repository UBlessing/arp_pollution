#include <stdio.h>
#include "pckt_header.h"

int main(void) {
	int i;
	ETHER_ADDR test_addr = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
	ARP_PACKET test_packet;

	test_packet.ether_hdr.dst = test_addr;

	return 0;
}
